<?php
require 'config/database.php';
require 'config/config.php';
$db = new Database();
$con = $db->conectar();

$id_transacion = isset($_GET['key']) ? $_GET['key'] : '0';

$error = '';
if ($id_transacion == '') {
    $error = 'Error al procesar la peticion';
} else {
    $sql = $con->prepare("select count(id) from compra where id_transacion=? and estado=? ");
    $sql->execute([$id_transacion, 'COMPLETED']);

    if ($sql->fetchColumn() > 0) {

        $sql = $con->prepare("select id, fecha,  email,total from compra where id_transacion=? and estado=? limit 1");
        $sql->execute([$id_transacion, 'COMPLETED']);
        $resultado = $sql->fetch(PDO::FETCH_ASSOC);
        $idCompra = $resultado['id'];
        $total = $resultado['total'];
        $fecha = $resultado['fecha'];


        $sqlDet = $con->prepare('select nombre, precio,cantidad from detalle_compra where id_compra=?');
        $sqlDet->execute([$idCompra]);
    } else {
        $error = 'Error al procesar la compra ';
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ultra Gaming</title>
    <link rel="icon" href="imagenes/icono.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link href="css/estilos.css" rel="stylesheet">
</head>

<body>

    <header data-bs-theme="dark">

        <div class="navbar navbar-dark navbar-expand-lg bg-dark ">
            <div class="container">
                <a href="index.php" class="navbar-brand d-flex align-items-center">
                     <strong>Ultra Gaming store</strong>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class=" collapse navbar-collapse" id="navbarHeader">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        
                        <li class="nav-item">
                            <a href="#" class="nav-link active"> Contacto </a>
                        </li>
                    </ul>

                </div>
            </div>
        </div>
    </header>
    <main>
        <div class="container">
            <div class="centered-content">
                <?php if (strlen($error) > 0) {
                ?>
                    <div class="row">
                        <div class="col-6">
                            <div style="text-align: center;">
                                <h3>
                                    <?php echo $error; ?>
                                </h3>
                            </div>
                        </div>

                    </div>
                <?php } else { ?>

                    <div class="row">
                        <div class="col">
                            <div style="text-align: right;">
                                <b>Folio de la compra: </b> <?php echo $id_transacion; ?><br>
                                <b>Fecha de la compra: </b> <?php echo $fecha; ?><br>
                                <b>Total:</b> <?php echo MONEDA . number_format($total, 2, '.', ','); ?><br>
                            </div>
                        </div>
                    </div>
                    <div class="col" >
                        <div class="table-responsive" style="text-align: center;">
                            <div >
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Cantidad</th>
                                            <th>Productos</th>
                                            <th>Importe</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($row_det = $sqlDet->fetch(PDO::FETCH_ASSOC)) {
                                            $importe = $row_det['precio'] * $row_det['cantidad']; ?>
                                            <tr>

                                                <td><?php echo $row_det['cantidad']; ?></td>
                                                <td><?php echo $row_det['nombre']; ?></td>
                                                <td><?php echo $importe; ?></td><br>

                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                                <br>
                                <a href="clases/enviar_email.php?key=<?php echo $id_transacion; ?>" class="btn btn-success">Enviar correo de factura </a>
                            </div>
                        </div>
                    </div>
            </div>
        <?php } ?>
        </div>
    </main>

</body>

</html>