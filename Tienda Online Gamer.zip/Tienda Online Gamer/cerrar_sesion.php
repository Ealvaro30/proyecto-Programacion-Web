<?php

require 'config/config.php';

session_destroy();

echo json_encode(['ok' => true]);
