CREATE DATABASE tienda_online_gamer;
USE tienda_online_gamer; 

CREATE TABLE `clientes` (
  `id` int primary key NOT NULL,
  `pnombre` varchar(20) NOT NULL,
  `snombre` varchar(20) NOT NULL,
  `papellido` varchar(20) NOT NULL,
  `sapellido` varchar(20) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `cedula` varchar(20) NOT NULL,
  `estatus` int DEFAULT NULL,
  `fecha_alta` datetime DEFAULT NULL,
  `fecha_modifica` datetime DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL
);

CREATE TABLE `usuarios` (
  `id` int primary key NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `password` varchar(120) NOT NULL,
  `activacion` int NOT NULL DEFAULT '0',
  `token` varchar(40) NOT NULL,
  `token_password` varchar(40) DEFAULT NULL,
  `password_request` int NOT NULL DEFAULT '0',
  `id_cliente` int NOT NULL,  
  FOREIGN KEY (`id_cliente`) REFERENCES `clientes`(`id`)
);

CREATE TABLE `compra` (
  `id` int primary key NOT NULL,
  `id_transacion` varchar(20) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `id_cliente` int DEFAULT NULL,  
  `total` decimal(10,2) DEFAULT NULL,
  FOREIGN KEY (`id_cliente`) REFERENCES `clientes`(`id`)
);
CREATE TABLE `categoria` (
  `idcategoria` int primary key  NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(250) DEFAULT NULL
);
CREATE TABLE `productos` (
  `idproducto` int primary key NOT NULL,
  `nombreproducto` varchar(50) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `descripcion` varchar(250) DEFAULT NULL,
  `descripdetalle` varchar(1000) DEFAULT NULL,
  `activo` bit(1) DEFAULT b'1',
  `stock` int NOT NULL,
  `id_categoria` int DEFAULT NULL,  -- Relación con categoría
  FOREIGN KEY (`id_categoria`) REFERENCES `categoria`(`idcategoria`)
);

CREATE TABLE `descuentos` (
  `id` int primary key NOT NULL,
  `id_producto` int NOT NULL,  
  `tipo_descuento` varchar(50) DEFAULT NULL, 
  `monto_descuento` decimal(10,2) DEFAULT NULL,
  `temporada` varchar(50) DEFAULT NULL, 
  `fecha_inicio` datetime DEFAULT NULL,
  `fecha_fin` datetime DEFAULT NULL,
  FOREIGN KEY (`id_producto`) REFERENCES `productos`(`idproducto`)
);
CREATE TABLE `detalle_compra` (
  `id` int primary key NOT NULL,
  `id_compra` int DEFAULT NULL,
  `id_producto` int DEFAULT NULL,
  `nombre` varchar(200) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `cantidad` int DEFAULT NULL,
  FOREIGN KEY (`id_compra`) REFERENCES `compra`(`id`),
  FOREIGN KEY (`id_producto`) REFERENCES `productos`(`idproducto`)
);

DELIMITER $$
--
-- Procedimientos
--
CREATE PROCEDURE `actualizarIntentos` (IN `numero` INT)   BEGIN
DECLARE inten int;
 select intentos into inten from intentos where idintentos =1;
    IF inten<=3 and inten>0 THEN
        UPDATE intentos SET intentos = (intentos-1) WHERE idintentos = 1;
        SELECT 'Solo quedan '+inten+' intentos' AS mensaje;
    END IF;
		IF inten<=>0 THEN
			SELECT 'No se puede mas intentos' AS mensaje;
        END IF;
    
END$$


DELIMITER $$

CREATE PROCEDURE `actualizarStock` (IN `cantidad` INT, IN `idpr` INT)   BEGIN
    DECLARE stockExist INT;
    DECLARE stock INT;
    DECLARE newStock INT;

    SELECT COUNT(*) INTO stockExist FROM productos WHERE idproducto = 2;

    IF stockExist = 1 THEN
        SELECT stock INTO stock FROM productos WHERE idproducto = idpr;
        SET newStock = stock - cantidad;
        UPDATE productos SET stock = newStock WHERE idproducto = idpr;
    ELSE
        SELECT 'No se encontraron los productos' AS mensaje;
    END IF;
END$$

CREATE  PROCEDURE `ExtraerTextoDesdeURL` (IN `url` VARCHAR(255))   BEGIN
    DECLARE id_start INT;
    DECLARE token_start INT;
    DECLARE id_end INT;
    DECLARE token_end INT;
    DECLARE id_value VARCHAR(255);
    DECLARE token_value VARCHAR(255);
    
    -- Buscar la posición de "id=" en la URL
    SET id_start = LOCATE('id=', url);
    
    -- Buscar la posición de "token=" en la URL
    SET token_start = LOCATE('token=', url);
    
    -- Si se encuentra "id=" y "token=" en la URL
    IF id_start > 0 AND token_start > 0 THEN
        -- Encontrar la posición del siguiente signo "&" después de "id="
        SET id_end = LOCATE('&', url, id_start);
        
        -- Encontrar la posición del siguiente signo "&" después de "token="
        SET token_end = LOCATE('&', url, token_start);
        
        -- Extraer el valor de "id" y "token"
        IF id_end > 0 THEN
            SET id_value = SUBSTRING(url, id_start + 3, id_end - id_start - 3);
        ELSE
            SET id_value = SUBSTRING(url, id_start + 3);
        END IF;
        
        IF token_end > 0 THEN
            SET token_value = SUBSTRING(url, token_start + 6, token_end - token_start - 6);
        ELSE
            SET token_value = SUBSTRING(url, token_start + 6);
        END IF;
        
        -- Mostrar los valores extraídos
        SELECT id_value AS ID, token_value AS Token;
    ELSE
        SELECT 'No se encontraron los parámetros "id" y "token" en la URL';
    END IF;
END$$

DELIMITER ;





INSERT INTO `clientes` (`id`, `pnombre`, `snombre`, `papellido`, `sapellido`, `email`, `telefono`, `cedula`, `estatus`, `fecha_alta`, `fecha_modifica`, `fecha_baja`) VALUES(2, 'alvaro', 'estrada', 'antonio', 'Estrada', 'amiguelcastro78@gmail.com', '88171710', '001-451278-4578L', 1, '2023-11-14 19:58:33', NULL, NULL);
INSERT INTO `clientes` (`id`, `pnombre`, `snombre`, `papellido`, `sapellido`, `email`, `telefono`, `cedula`, `estatus`, `fecha_alta`, `fecha_modifica`, `fecha_baja`) VALUES(3, 'alvaro', 'estrada', 'antonio', 'Estrada', 'ealvaroestrada180@gmail.com', '88171710', '001-451278-4578L', 1, '2024-03-24 20:18:55', NULL, NULL);



INSERT INTO `compra` (`id`, `id_transacion`, `fecha`, `estado`, `email`, `id_cliente`, `total`) VALUES(1, '2P368986EM7612033', '2023-11-15 18:34:04', 'COMPLETED', 'sb-p6g4927865405@business.example.com', 'XD55BR46KJXHN', 26910.00);
INSERT INTO `compra` (`id`, `id_transacion`, `fecha`, `estado`, `email`, `id_cliente`, `total`) VALUES(2, '7M506375FW941084X', '2023-11-15 18:35:11', 'COMPLETED', 'sb-p6g4927865405@business.example.com', 'XD55BR46KJXHN', 26910.00);
INSERT INTO `compra` (`id`, `id_transacion`, `fecha`, `estado`, `email`, `id_cliente`, `total`) VALUES(3, '8MM04741AK192724C', '2023-11-15 20:21:54', 'COMPLETED', 'sb-p6g4927865405@business.example.com', 'XD55BR46KJXHN', 655.50);
INSERT INTO `compra` (`id`, `id_transacion`, `fecha`, `estado`, `email`, `id_cliente`, `total`) VALUES(4, '0E7456785G732894A', '2023-11-15 20:34:24', 'COMPLETED', 'sb-p6g4927865405@business.example.com', 'XD55BR46KJXHN', 655.50);
INSERT INTO `compra` (`id`, `id_transacion`, `fecha`, `estado`, `email`, `id_cliente`, `total`) VALUES(5, '4HT93891H7842881F', '2023-11-15 20:35:49', 'COMPLETED', 'sb-p6g4927865405@business.example.com', 'XD55BR46KJXHN', 132.05);
INSERT INTO `compra` (`id`, `id_transacion`, `fecha`, `estado`, `email`, `id_cliente`, `total`) VALUES(6, '5PV87702L18268458', '2024-03-25 03:21:05', 'COMPLETED', 'sb-p6g4927865405@business.example.com', 'XD55BR46KJXHN', 840.00);
INSERT INTO `compra` (`id`, `id_transacion`, `fecha`, `estado`, `email`, `id_cliente`, `total`) VALUES(7, '3K887197EL591794Y', '2024-05-12 20:12:27', 'COMPLETED', 'sb-p6g4927865405@business.example.com', 'XD55BR46KJXHN', 5899.50);






INSERT INTO `detalle_compra` (`id`, `id_compra`, `id_producto`, `nombre`, `precio`, `cantidad`) VALUES(1, 1, 1, 'Monitor gamer Acer Predator 27\'', 299.00, 100);
INSERT INTO `detalle_compra` (`id`, `id_compra`, `id_producto`, `nombre`, `precio`, `cantidad`) VALUES(2, 2, 1, 'Monitor gamer Acer Predator 27\'', 299.00, 100);
INSERT INTO `detalle_compra` (`id`, `id_compra`, `id_producto`, `nombre`, `precio`, `cantidad`) VALUES(3, 3, 3, 'Mouse Acer ', 69.00, 10);
INSERT INTO `detalle_compra` (`id`, `id_compra`, `id_producto`, `nombre`, `precio`, `cantidad`) VALUES(4, 4, 3, 'Mouse Acer ', 69.00, 10);
INSERT INTO `detalle_compra` (`id`, `id_compra`, `id_producto`, `nombre`, `precio`, `cantidad`) VALUES(5, 5, 3, 'Mouse Acer ', 69.00, 1);
INSERT INTO `detalle_compra` (`id`, `id_compra`, `id_producto`, `nombre`, `precio`, `cantidad`) VALUES(6, 5, 5, ' AUDIFONO KLIP ', 70.00, 1);
INSERT INTO `detalle_compra` (`id`, `id_compra`, `id_producto`, `nombre`, `precio`, `cantidad`) VALUES(7, 6, 18, ' MONITOR AOC 24 ', 210.00, 4);
INSERT INTO `detalle_compra` (`id`, `id_compra`, `id_producto`, `nombre`, `precio`, `cantidad`) VALUES(8, 7, 3, 'Mouse Acer ', 69.00, 90);


DELIMITER $$
CREATE TRIGGER `after_insert_detalle_compra` AFTER INSERT ON `detalle_compra` FOR EACH ROW BEGIN
    UPDATE productos
    SET stock = stock - NEW.cantidad
    WHERE idproducto = NEW.id_producto;
END
$$
DELIMITER ;

CREATE TABLE `intentos` (
  `idintentos` int NOT NULL,
  `intentos` int NOT NULL
) ;






INSERT INTO `productos` (`idproducto`, `nombreproducto`, `precio`, `descripcion`, `descripdetalle`, `activo`, `descuento`, `stock`) VALUES(1, 'Monitor gamer Acer Predator 27\'', 299.00, 'Monitor gaming Acer 144Hz curvo ', '<p>Monitor gaming con una tasa de refresco de pantalla de 144Hz con pantalla semi curva de 27\' en la diagonal </p><br><b>Caracteristicas:</b>\n<br> Marca: Acer Predator <br>\nModelo: ER34251H<br> Material: Aluminio y plastico <br>Resolucion: 1920 x 1080 Full HD<br> ', b'1', 10, 0);
INSERT INTO `productos` (`idproducto`, `nombreproducto`, `precio`, `descripcion`, `descripdetalle`, `activo`, `descuento`, `stock`) VALUES(2, 'Monitor gamer Asus ', 199.00, 'Monitor gaming Asus 75Hz plano ', '<p>Monitor gaming con una tasa de refresco de pantalla de 75Hz con pantalla plana de 24\' en la diagonal </p><br><b>Caracteristicas:</b>\n<br> Marca: Asus <br>\nModelo: YHERE45343 <br> Material: Aluminio y plastico <br>Resolucion: 3060 X 1920 Full HD<br> ', b'1', 0, 100);
INSERT INTO `productos` (`idproducto`, `nombreproducto`, `precio`, `descripcion`, `descripdetalle`, `activo`, `descuento`, `stock`) VALUES(3, 'Mouse Acer ', 69.00, 'Mouse retroiluminado negro mate', '<p>Monuse retroiluminado color negro con repuesa aptica </p><br><b>Caracteristicas:</b>\n<br> Marca: Acer <br>\nModelo: ITYTR645H <br> Material:  plastico <br>Botones: 6 <br> ', b'1', 5, 189);
INSERT INTO `productos` (`idproducto`, `nombreproducto`, `precio`, `descripcion`, `descripdetalle`, `activo`, `descuento`, `stock`) VALUES(4, ' AUDIFONO GAMER XTECH ', 190.00, 'AUDIFONO GAMER XTH-551 XTECH', '<p>Audifono Gamer XTH-551 Auricular Factor de forma: Supraaural Máxima potencia de salida : 50mW total Frecuencia: 20Hz~20kHz Impedancia: 32O±15% Sensibilidad: 105dB Micrófono Factor de forma: En el audífono Directividad: Omnidireccional Frecuencia: 20Hz~20kHz Sensibilidad: -43dB Tipo de conexión: 3,5mm (TRRS) y USB para alimentación. Incluye adaptador hembra de 3,5mm a dos enchufes de 3,5mm (TRS) </p><br><b>Caracteristicas: </b>\n<br> Marca: XTECH <br>\nModelo: ISDTR987H <br> Material:  <br>Botones: De silenciamiento y volumen en la cápsula de control Longitud del cable: 2m  <br> ', b'1', 0, 120);
INSERT INTO `productos` (`idproducto`, `nombreproducto`, `precio`, `descripcion`, `descripdetalle`, `activo`, `descuento`, `stock`) VALUES(5, ' AUDIFONO KLIP ', 70.00, 'AUDIFONO KHS-550RD KLIP', '<p> AUDIFONO KHS-550RD KLIP | Auriculares Estéreo Modelo KHS-550RD Micrófono Omnidireccional </p><br><b>Caracteristicas: Máxima potencia de salida: 20mW Margen de frecuencias: 20Hz-20.000Hz Impedancia: 32? ± 15% Sensibilidad: 105 ± 3dB/mW (N.P.S a 1kHz) Conectividad: 3,5mm </b>\n<br> Marca: KLIP <br>\nModelo: ISDTR268H <br> Material:  <br>Botones: Botón multifunción (Pausa/Reproducir/Próxima pista/Contestar/Colgar/Ignorar llamada) <br> ', b'1', 5, 209);
INSERT INTO `productos` (`idproducto`, `nombreproducto`, `precio`, `descripcion`, `descripdetalle`, `activo`, `descuento`, `stock`) VALUES(6, 'CASE GAMER XTECH ', 90.00, 'CASE GAMER XT-GMR4 XTECH', '<p> CASE GAMER XT-GMR4 XTECH | PHOBOS | Tipo de chasis: Chasis para torre mediana | Formato de la placa madre: ATX/Micro-ATX  </p><br><b>Caracteristicas: Puertos frontales: 2 puertos USB 2.0, 1 puerto USB 3.0, Dos puertos para audio de alta definición, de 3,5mm </b>\n<br> Marca: XTECH <br>\nModelo: ISDD6987H <br> Material:  <br>Botones:  Botón de alimentación con luz LED y botón de reinicio. <br> ', b'1', 0, 68);
INSERT INTO `productos` (`idproducto`, `nombreproducto`, `precio`, `descripcion`, `descripdetalle`, `activo`, `descuento`, `stock`) VALUES(7, 'LAPTOP ASUS 15.6  ', 420.00, 'LAPTOP ASUS 15.6 CI7-12700H 1TB SSD 16GB RTX4', '<p> COMPUTADORA LAPTOP ASUS FX507ZV4-LP052W | Procesador Intel I7-12700H | RAM: 16 GB 3200 DDR4 (2/2) | Almacenamiento: 1TB PCIe® 4.0 NVMe™ M.2 SSD | Pantalla 15.6 FHD 16:9 (1920 x 1080) 144hz Display | Tarjeta gráfica NVIDIA® GeForce® RTX™ 4060 GPU 8GB   </p><br><b>Caracteristicas:  Teclado retroiluminado RGB | Win 11 Home </b>\n<br> Marca: ASUS <br>\nModelo: ISV3XRSH <br> Material:  <br>Botones:   <br> ', b'1', 0, 34);
INSERT INTO `productos` (`idproducto`, `nombreproducto`, `precio`, `descripcion`, `descripdetalle`, `activo`, `descuento`, `stock`) VALUES(8, 'COMPUTADORA DELL OPTIPLEX SFF 3000 ', 640.00, ' COMPUTADORA DELL OPTIPLEX SFF 3000 I5-12500 8 ', '<p> COMPUTADORA DELL OPTIPLEX 3000 SFF | Procesador Intel® Core™ i5-12500 de 3.00 GHZ | Disco Duro SSD 256 GB NVME (bahía libre 3.5) | Memoria RAM de 8GB DDR4 2666Mhz (1 /2). | Intel® UHD Graphics 770 | 4 x USB 2.0 | 4 x USB 3.0 | 1 x RJ-45. | 1 x HDMI 1.4. | 1 x DisplayPort   </p><br><b>Caracteristicas:   </b>\n<br> Marca: DELL <br>\nModelo: ISV3L98H <br> Material:  <br>Botones:   <br> ', b'1', 0, 78);
INSERT INTO `productos` (`idproducto`, `nombreproducto`, `precio`, `descripcion`, `descripdetalle`, `activo`, `descuento`, `stock`) VALUES(9, 'PARLANTE XTECH ', 58.00, 'PARLANTE XTS-375BK 2.1 XTECH ', '<p> PARLANTE XTS-375BK 2.1 XTECH | Sistema de parlantes de 2.1 canales | Máxima potencia de salida (RMS) : USB 5VCC </p><br><b>Caracteristicas:  Tipo de conexión: Entrada de audio: auxiliar de 3,5mm Puerto USB Ranura para microtarjeta SD™ Salida de audio: 3,5mm | Máxima potencia de salida (RMS): 12W  </b>\n<br> Marca: XTECH <br>\nModelo: 0LQ3L98H <br> Material:  <br>Botones:   <br> ', b'1', 5, 170);
INSERT INTO `productos` (`idproducto`, `nombreproducto`, `precio`, `descripcion`, `descripdetalle`, `activo`, `descuento`, `stock`) VALUES(10, 'MICROFONO SNOWBALL ICE LOGITEC', 70.00, 'MICROFONO USB 988-000067 SNOWBALL ICE LOGITEC ', '<p> Micrfono USB SNOWBALL ICE Black 988-000067. Es la forma más rápida y sencilla de conseguir un sonido de alta calidad para grabaciones y streaming. Está incluso certificado por Skype, lo que garantiza unos resultados de sonido excelentes sin importar cómo o cuando lo use—en casa, en la oficina o en el estudio. Patrón cardioide con pastilla para capturar voces, música, podcasts, juegos y más </p><br><b>Caracteristicas:</b>\n<br> Marca: LOGITEC <br>\nModelo: ER342HQH<br> Material:<br> Resolucion <br> ', b'1', 0, 100);
INSERT INTO `productos` (`idproducto`, `nombreproducto`, `precio`, `descripcion`, `descripdetalle`, `activo`, `descuento`, `stock`) VALUES(11, 'PROYECTOR BENQ BLACK', 500.00, 'PROYECTOR BENQ MX631ST BLACK ', '<p> Proyector Benq Ideal para Oficinas o Escuelas Modelo MX631ST Tecnología de Exhibición DLP Resolución Nativa XGA (1024 x 768) Brillo 3200 ANSI Lúmenes Contraste 13000:1 Lampara 4,500/ 6,000/ 6, 500/ 10,000 horas Colores 1.07 Billones </p><br><b>Caracteristicas:</b>\n<br> Marca: BENQ <br>\nModelo: ER342GR3<br> Material:<br> Resolucion: Tamaño de Imagen 60~120 Resolución soportada VGA (640 x 480) hasta WUXGA_RB (1920 x 1200)<br> ', b'1', 0, 50);
INSERT INTO `productos` (`idproducto`, `nombreproducto`, `precio`, `descripcion`, `descripdetalle`, `activo`, `descuento`, `stock`) VALUES(12, 'CAMARA WEB XTECH', 437.00, 'CAMARA WEB XTW-480 XTECH', '<p>CAMARA WEB XTW-480 XTECH | Tipo: Cámara web 480P USB | Micrófono integrado permite conversaciones claras | Clip universal para utilizarla en escritorios, laptops y monitores </p><br><b>Caracteristicas:</b>\n<br> Marca: XTECH<br>\nModelo: ER342F23<br> Material:<br> <br> ', b'1', 0, 100);
INSERT INTO `productos` (`idproducto`, `nombreproducto`, `precio`, `descripcion`, `descripdetalle`, `activo`, `descuento`, `stock`) VALUES(13, ' ENFRIADOR P/LAPTOP ', 30.00, 'ENFRIADOR P/LAPTOP ARG-CF-1584', '<p>Sistema de enfriamiento de base portátil, con una superficie de rejilla completa que proporciona circulación de aire de enfriamiento total alrededor de su laptop con un diseño moderno, ofrece un posicionamiento ergonómico para mayor comodidad al usar su laptop. </p><br><b>Caracteristicas:</b>\n<br> Marca: ARGOM<br>\nModelo: ER3LMF23<br> <br> <br> ', b'1', 0, 300);
INSERT INTO `productos` (`idproducto`, `nombreproducto`, `precio`, `descripcion`, `descripdetalle`, `activo`, `descuento`, `stock`) VALUES(14, 'MONITOR 27 ASUS ', 260.00, 'MONITOR 27 ASUS VA27EHEY', '<p> MONITOR 27 ASUS VA27EHEY. Monitor para el cuidado de los ojos. Frecuencia de actualización de hasta 75Hz con tecnología Adaptive-Sync. VESA de montaje en pared para ahorrar espacio en el escritorio. </p><br><b>Caracteristicas:</b>\n<br> Marca: ASUUS<br>\nModelo: ER3LMF23<br> <br> <br> ', b'1', 10, 200);
INSERT INTO `productos` (`idproducto`, `nombreproducto`, `precio`, `descripcion`, `descripdetalle`, `activo`, `descuento`, `stock`) VALUES(15, ' PROCESADOR CORE LGA 1700 ', 161.00, 'PROCESADOR CORE I5-13600K LGA 1700', '<p>PROCESADOR CORE I5-13600K LGA 1700 |Total Cores 14 | # of Performance-cores 6 | # of Efficient-cores 8 | Total Threads 20 | Max Turbo Frequency 5.10 GHz | Cache 24 MB Intel® Smart Cache | Max Memory Size (dependent on memory type) 128 GB </p><br><b>Caracteristicas:</b>\n<br> Marca: INTEL<br>\nModelo: E53GE2F23<br> <br> <br> ', b'1', 0, 120);
INSERT INTO `productos` (`idproducto`, `nombreproducto`, `precio`, `descripcion`, `descripdetalle`, `activo`, `descuento`, `stock`) VALUES(16, ' TECLADO ARGOM', 17.00, 'TECLADO ARG-KB7424 INGLES ARGOM', '<p> Teclado USB en Ingles Modelo ARG-KB-7424 Diseño ergonómico, atractivo y confortable. Tiempo de vida de las teclas: 10 millones de pulsos. Configuración automática Plástico de larga duración Teclas suave al tacto para una digitación uniforme y precisa Patas traseras ajustables para inclinación adecuada  </p><br><b>Caracteristicas:</b>\n<br> Marca: ARGOM<br>\nModelo: YTRE1GF23<br> <br> <br> ', b'1', 0, 300);
INSERT INTO `productos` (`idproducto`, `nombreproducto`, `precio`, `descripcion`, `descripdetalle`, `activo`, `descuento`, `stock`) VALUES(17, ' RATON GAMER USB PRIMUS', 65.00, 'RATON GAMER PMO-102 GLADIUS 8200T USB PRIMUS', '<p> RATON GAMER PMO-102 GLADIUS 8200T USB PRIMUS. TIPO DE SUJECIÓN: DISEÑADO PARA LA MANO DERECHA SENSOR TYPE : ÓPTICO AVAGO  </p><br><b>Caracteristicas:</b>\n<br> Marca: PRIMUS <br>\nModelo: 05KCQF23<br>BOTONES:   6 BOTONES PROGRAMABLES<br> <br> ', b'1', 25, 110);
INSERT INTO `productos` (`idproducto`, `nombreproducto`, `precio`, `descripcion`, `descripdetalle`, `activo`, `descuento`, `stock`) VALUES(18, ' MONITOR AOC 24 ', 210.00, 'MONITOR AOC 24 24B2XH', '<p> MONITOR AOC 24 24B2XH. tamaño de pantalla vertical 24 </p><br><b>Caracteristicas:</b>\n<br> Marca: AOC<br>\nModelo: 05KC95T23<br>RESOLUCION: FHD 1080p<br> <br> ', b'1', 0, 76);






INSERT INTO `usuarios` (`id`, `usuario`, `password`, `activacion`, `token`, `token_password`, `password_request`, `id_cliente`) VALUES(2, 'juan', '$2y$10$VetqMWE1XnD3XdSpoTxfHeRbGjpZpRFPx1ITF8YdZIVA52IUi9Aay', 1, '6af3d483de883b900325ba4b75f82c97', NULL, 0, 2);
INSERT INTO `usuarios` (`id`, `usuario`, `password`, `activacion`, `token`, `token_password`, `password_request`, `id_cliente`) VALUES(3, 'alvaro', '$2y$10$EcjF5jMDemQJlzh76xJ8UeljS2uThby2IBjV/.JUlOK8J8tC0eJ5O', 1, '3b2c54db1bb8ce408ae8c0817d5d5bde', NULL, 0, 3);
INSERT INTO `usuarios` (`id`, `usuario`, `password`, `activacion`, `token`, `token_password`, `password_request`, `id_cliente`) VALUES(3, 'alvaro', '$2y$10$EcjF5jMDemQJlzh76xJ8UeljS2uThby2IBjV/.JUlOK8J8tC0eJ5O', 1, '3b2c54db1bb8ce408ae8c0817d5d5bde', NULL, 0, 3);


  





