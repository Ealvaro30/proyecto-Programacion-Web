<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'src/PHPMailer.php';
require 'src/SMTP.php';
require 'src/Exception.php';

$email_user = "tiendaonlinegamer710@gmail.com";
$email_password = "qwkxpydzxwskrzgp";
$the_subject = "Detalles de su compra ";
$address_to = "ealvaroestrada180@gmail.com";
$from_name = "Servicio de compras";
$phpmailer = new PHPMailer();

$phpmailer->Username = $email_user;
$phpmailer->Password = $email_password; 
$phpmailer->SMTPSecure = 'tls'; 
$phpmailer->Host = "smtp.gmail.com";
$phpmailer->Port = 587; 
$phpmailer->IsSMTP(); 
$phpmailer->SMTPAuth = true;

$phpmailer->setFrom($phpmailer->Username,$from_name);
$phpmailer->AddAddress($address_to); // recipients email

$phpmailer->Subject = $the_subject;	
$cuerpo = '<h4>Gracias por su compra en Ultra Gaming</h4>';
$cuerpo .= '
<div class="row">
    <div class="col">
        <b>Folio de la compra </b>1<br>
        <b>Fecha de la compra</b> 1<br>
        <b>Total:</b>  1<br>
    </div>
</div>
<div class="row">
    <div class="col">
        <table class="table">
            <thead>
                <tr>
                    <th>Cantidad</th>
                    <th>Productos</th>
                    <th>Importe</th>
                </tr>
            </thead>
            <tbody>';
$cuerpo .= 
            '</tbody>
        </table>
    </div>
</div>';


$phpmailer->Body = mb_convert_encoding($cuerpo, 'UTF-8', 'ISO-8859-1');

$phpmailer->IsHTML(true);

$phpmailer->Send();

?>