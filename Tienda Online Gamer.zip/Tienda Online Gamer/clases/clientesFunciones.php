<?php

function esNulo(array $parametros)
{
    foreach ($parametros as $parametro) {
        if (strlen(trim($parametro)) < 1) {
            return true;
        }
    }
    return false;
}

function esEmail($email)
{
    if (filter_var(($email . FILTER_VALIDATE_EMAIL))) {
        return true;
    }
    return false;
}

function validaPassword($password, $repassword)
{
    if (strcmp($password, $repassword) === 0) {
        return true;
    }
    return false;
}


function generarToken()
{
    return md5(uniqid(mt_rand(), false));
}
function registraCliente(array $datos, $con)
{
    $sql = $con->prepare("INSERT INTO clientes(pnombre,snombre,papellido ,sapellido ,email ,telefono ,cedula,estatus,fecha_alta)values
    (?,?,?,?,?,?,?,1,now())");
    if ($sql->execute($datos)) {
        return $con->lastInsertId();
    }
    return 0;
}

function registraUsuario(array $datos, $con)
{
    $sql = $con->prepare("INSERT INTO usuarios (usuario,password,token,id_cliente) VALUES
    (?,?,?,?)");
    if ($sql->execute($datos)) {
        return $con->lastInsertId();
    }
    return 0;
}
function usuarioExiste($usuario, $con)
{
    $sql = $con->prepare("SELECT id FROM usuarios WHERE usuario LIKE ? LIMIT 1");
    $sql->execute([$usuario]);
    if ($sql->fetchColumn() > 0) {
        return true;
    }
    return false;
}
function emailExiste($email, $con)
{
    $sql = $con->prepare("SELECT id FROM clientes WHERE email LIKE ? LIMIT 1");
    $sql->execute([$email]);
    if ($sql->fetchColumn() > 0) {
        return true;
    }
    return false;
}
function mostrarMensaje(array $erros)
{
    if (count($erros) > 0) {
        echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">';
        foreach ($erros as $error) {
            echo '<li>' . $error . '</li>';
        }
        echo '<ul>';
        echo ' <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
    }
}
function validaToken($id, $token, $con)
{
    $msg = '';
    $sql = $con->prepare("SELECT id FROM usuarios WHERE id = ? AND token LIKE ?
    LIMIT 1");
    $sql->execute([$id, $token]);
    if ($sql->fetchColumn() > 0) {
        if (activarUsuario($id, $con)) {
            $msg = "Cuenta activada";
        } else {
            $msg = "Error al activar cuenta.";
        }
    } else {
        $msg = "No existe el registro del cliente ";
    }
    return $msg;
}

function activarUsuario($id, $con)
{
    $sql = $con->prepare("UPDATE usuarios SET activacion = 1 WHERE id = ?");
    return $sql->execute([$id]);
}



function login($usuario, $password, $con)
{
    $error = '';
    $intentos = (int)$_SESSION['intentos'];
    $sql = $con->prepare("SELECT * FROM usuarios WHERE usuario LIKE ? LIMIT 1");
    $sql->execute([$usuario]);
    // $row = $sql->fetch(PDO::FETCH_ASSOC);

    if ($row = $sql->fetch(PDO::FETCH_ASSOC)) {
        if (esActivo($usuario, $con)) {
            if (password_verify($password, $row['password'])) {
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['user_name'] = $row['usuario'];
                $_SESSION['id_usuario'] = $row['id_cliente'];
                header('Location: index.php');
                exit;
            } else {
                if ($intentos < 3) {
                    $intentos++;
                    (int)$_SESSION['intentos'] = $intentos;
                } else {
            
                    if (!empty($_SESSION['intentos']) && (int)$_SESSION['intentos'] === 3) {
                        echo '<div class="d-flex align-items-center">
                        <h1 style="text-align: center;"><strong role="status">Sistema bloqueado espere 2 segundos...</strong></h1>
                        <div class="spinner-border ms-auto" aria-hidden="true"></div>
                <script>
            setTimeout(function() {
                    window.location.href = "https://tiendaultragaming.000webhostapp.com/index.php";
            }, 2000);
          </script>';
                        // Detiene el script para que no siga ejecutándose después de la redirección
                        exit;
                        $_SESSION['intentos'] = 0;
                        header('Location: index.php');
                        exit;
                    } else {
            
                        if ($error) {
                            $_SESSION['intentos'] = isset($_SESSION['intentos']) ? $_SESSION['intentos'] + 1 : 1;
                        }
                    }
                }

            }
            return  'Usuario y/o contraseña incorrecta intentos: ' . $_SESSION['intentos'];
        } else {
            if ($intentos < 3) {
                $intentos++;
                (int)$_SESSION['intentos'] = $intentos;
            } else {
        
                if (!empty($_SESSION['intentos']) && (int)$_SESSION['intentos'] === 3) {
                    echo '<div class="d-flex align-items-center">
                    <h1 style="text-align: center;"><strong role="status">Sistema bloqueado espere 2 segundos...</strong></h1>
                    <div class="spinner-border ms-auto" aria-hidden="true"></div>
                    <script>
                setTimeout(function() {
                        window.location.href = "https://tiendaultragaming.000webhostapp.com/index.php";
                }, 2000);
              </script>';
                    // Detiene el script para que no siga ejecutándose después de la redirección
                    exit;
                    $_SESSION['intentos'] = 0;
                    header('Location: index.php');
                    exit;
                } else {
        
                    if ($error) {
                        $_SESSION['intentos'] = isset($_SESSION['intentos']) ? $_SESSION['intentos'] + 1 : 1;
                    }
                }
            }
            return $error = 'El usuario no ha sido activado intentos: ' . $_SESSION['intentos'];
        }
    } else {
        if ($intentos < 3) {
            $intentos++;
            (int)$_SESSION['intentos'] = $intentos;
        } else {
    
            if (!empty($_SESSION['intentos']) && (int)$_SESSION['intentos'] === 3) {
                echo '<div class="d-flex align-items-center">
                <h1 style="text-align: center;"><strong role="status">Sistema bloqueado espere 2 segundos...</strong></h1>
                <div class="spinner-border ms-auto" aria-hidden="true"></div>
                <script>
            setTimeout(function() {
                    window.location.href = "https://tiendaultragaming.000webhostapp.com/index.php";
            }, 2000);
          </script>';
                // Detiene el script para que no siga ejecutándose después de la redirección
                exit;
                $_SESSION['intentos'] = 0;
                header('Location: index.php');
                exit;
            } else {
    
                if ($error) {
                    $_SESSION['intentos'] = isset($_SESSION['intentos']) ? $_SESSION['intentos'] + 1 : 1;
                }
            }
        }
        return $error = 'Usuario no encontrado intentos: ' . $_SESSION['intentos'];
    }
    
}


function esActivo($usuario, $con)
{
    $sql = $con->prepare("SELECT activacion FROM usuarios WHERE usuario LIKE ? LIMIT 1");
    $sql->execute([$usuario]);
    $row = $sql->fetch(PDO::FETCH_ASSOC);
    $activo = $row['activacion'];
    if ($activo == 1) {
        return true;
    } else {
        return false;
    }
}
function cerrarSesion()
{
    if (isset($_SESSION['user_id'])) {
        // Mostrar un mensaje de confirmación en JavaScript
        echo '<script>';
        echo 'if (confirm("¿Desea cerrar la sesión?2")) {';
        echo '    ' . 'unset($_SESSION["user_id"]);'; 
        echo '    ' . 'unset($_SESSION["user_name"]);'; 
        echo '    ' . 'unset($_SESSION["id_usuario"]);'; 
        echo '    ' . 'window.location.href = "index.php";'; 
        echo '} else {';
        echo '    ' . 'window.location.href = "index.php";';
        echo '}';
        echo '</script>';
        return true;
    } else {
        return false;
    }
}
