<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'src/PHPMailer.php';
require 'src/SMTP.php';
require 'src/Exception.php';
require '../config/database.php';
require '../config/config.php';
$db = new Database();
$con = $db->conectar();

$id_transacion = isset($_GET['key']) ? $_GET['key'] : '0';
$error = '';
if (isset($_SESSION['id_usuario'])) {
    $idU = (int)$_SESSION['id_usuario'];
    $sql = $con->prepare("select email from clientes where id=?");
    $sql->execute([$idU]);
    $resultado = $sql->fetch(PDO::FETCH_ASSOC);
    $email = $resultado['email'];
}
if ($id_transacion == '') {
    $error = 'Error al procesar la peticion';
} else {

    $sql = $con->prepare("select count(id) from compra where id_transacion=? and estado=? ");
    $sql->execute([$id_transacion, 'COMPLETED']);

    if ($sql->fetchColumn() > 0) {

        $sql = $con->prepare("select id, fecha,  email,total from compra where id_transacion=? and estado=? limit 1");
        $sql->execute([$id_transacion, 'COMPLETED']);
        $resultado = $sql->fetch(PDO::FETCH_ASSOC);
        $idCompra = $resultado['id'];
        $total = $resultado['total'];
        $fecha = $resultado['fecha'];
    


        $sqlDet = $con->prepare('select nombre, precio,cantidad from detalle_compra where id_compra=?');
        $sqlDet->execute([$idCompra]);
    } else {
        $error = 'Error al procesar la compra ';
    }
}

$email_user = "tiendaonlinegamer710@gmail.com";
$email_password = "qwkxpydzxwskrzgp";
$the_subject = "Detalles de su compra ";
$address_to = $email;
$from_name = "Servicio de compras";
$phpmailer = new PHPMailer();

$phpmailer->Username = $email_user;
$phpmailer->Password = $email_password;

$phpmailer->SMTPSecure = 'tls'; 
$phpmailer->Host = "smtp.gmail.com"; 
$phpmailer->Port = 587; 
$phpmailer->IsSMTP(); 
$phpmailer->SMTPAuth = true;

$phpmailer->setFrom($phpmailer->Username, $from_name);
$phpmailer->AddAddress($address_to); 

$phpmailer->Subject = $the_subject;
$cuerpo = '<h4>Gracias por su compra en Ultra Gaming</h4>';
$cuerpo .= '
<div class="row">
    <div class="col">
        <b>Folio de la compra:  </b>' . $id_transacion . '<br>
        <b>Fecha de la compra: </b> ' . $fecha . '<br><br>
    </div>
</div>
<div class="row">
    <div class="col">
        <table class="table">
            <thead>
                <tr>
                    <th>Cantidad</th>
                    <th>Productos</th>
                    <th>Importe</th>
                </tr>
            </thead>
            <tbody>';
while ($row_det = $sqlDet->fetch(PDO::FETCH_ASSOC)) {
    $importe = $row_det['precio'] * $row_det['cantidad'];
    $cuerpo .= '
                <tr>
                    <td>' . $row_det['cantidad'] . '</td>
                    <td>' . $row_det['nombre'] . '</td>
                    <td>' . $importe . '</td>
                </tr>';
}
$cuerpo .= '
            </tbody>
        </table>
    </div>
</div>
<div class="row">
    <div class="col">
        <hr> <!-- Línea horizontal para separar -->
        <br> <!-- Agregar un salto de línea aquí -->
        <b>Total:</b> ' . MONEDA . number_format($total, 2, '.', ',') . '<br>
    </div>
</div>';




$phpmailer->Body    =  mb_convert_encoding($cuerpo, 'UTF-8', 'ISO-8859-1');
$phpmailer->IsHTML(true);

$phpmailer->Send();
header("Location: http://localhost/Tienda%20Online%20Gamer/index.php");
exit();
