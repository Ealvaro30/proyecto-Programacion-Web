<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;



class Mailer
{
    function enviarEmail($email, $asunto, $cuerpo)
    {
        try {
            require_once './clases/src/PHPMailer.php';
            require './clases/src/SMTP.php';
            require './clases/src/Exception.php';
            require_once './config/config.php';


            $phpmailer = new PHPMailer();

            $email_user = MAIL_USER;
            $email_password = MAIL_PASS;
            $the_subject = $asunto;
            $address_to = MAIL_USER;
            $from_name = "Servicios tienda online";


            $phpmailer->Username = $email_user;
            $phpmailer->Password = $email_password;
   
            $phpmailer->SMTPSecure = 'tls'; 
            $phpmailer->Host = "smtp.gmail.com"; 
            $phpmailer->Port = MAIL_PORT; 
            $phpmailer->IsSMTP(); 
            $phpmailer->SMTPAuth = true;

            $phpmailer->setFrom($phpmailer->Username, $from_name);
            $phpmailer->AddAddress($email, 'Activacion de cuentas'); 
            $phpmailer->Subject = $the_subject;

            $phpmailer->Body    =  mb_convert_encoding($cuerpo, 'UTF-8', 'ISO-8859-1');
            $phpmailer->IsHTML(true);

            if ($phpmailer->Send()) {
                return true;
            } else {
                return false;
            }
            header("Location: http://localhost/Tienda%20Online%20Gamer/index.php");
            exit();
        } catch (Exception $e) {
            echo "No se pudo enviar el correo. Error de envio: {$email->ErrorInfo}";
            return false;
        }
    }
}