<?php


require '../config/database.php';
require '../config/config.php';
$db = new Database();
$con = $db->conectar();

$json = file_get_contents('php://input');
$datos = json_decode($json, true);


if (is_array($datos)) {
    $id_transacion = $datos['detalles']['id'];
    $total = $datos['detalles']['purchase_units'][0]['amount']['value'];
    $status = $datos['detalles']['status'];
    $fecha = $datos['detalles']['update_time'];
    $fecha_nueva = date('Y-m-d H:i:s', strtotime($fecha));
    $email = $datos['detalles']['payer']['email_address'];
    $id_cliente = $datos['detalles']['payer']['payer_id'];

    $sql = $con->prepare("insert into compra(id_transacion,fecha,estado,email,id_cliente,total)values(?,?,?,?,?,?)");
    $sql->execute([$id_transacion, $fecha_nueva, $status, $email, $id_cliente, $total]);
    $id = $con->lastInsertId();

    $productos = isset($_SESSION['carrito']['productos']) ? $_SESSION['carrito']['productos'] : null;
    
    if ($productos != null) {
        foreach ($productos as $clave => $cantidad) {
            $sqlGetProducto = $con->prepare("SELECT idproducto, nombreproducto, precio,$cantidad AS cantidad FROM productos WHERE idproducto=? AND activo=1");
            $sqlGetProducto->execute([$clave]);
            $row_prod = $sqlGetProducto->fetch(PDO::FETCH_ASSOC);
    
            if ($row_prod) {
                $producId = $row_prod['idproducto'];
                $precio = $row_prod['precio'];
                $nombre = $row_prod['nombreproducto'];
                $cantidad = $row_prod['cantidad'];
                $subtotal = $cantidad * $precio;
                $total += $subtotal;
                $sqlInsertDetalle = $con->prepare("INSERT INTO detalle_compra(id_compra, id_producto, nombre, precio, cantidad) VALUES (?, ?, ?, ?, ?)");
                $sqlInsertDetalle->execute([$id, $producId, $nombre, $precio, $cantidad]);
            }
        }

        unset($_SESSION['carrito']);

    }
    else {
        echo 'Ha ocurrido un error de insercion';
    }
}
