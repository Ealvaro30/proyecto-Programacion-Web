<?php
require 'config/database.php';
require 'config/config.php';

$db = new Database();
$con = $db->conectar();
$url_actual = "http" . (isset($_SERVER['HTTPS']) ? "s" : "") . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

try {
    if (isset($_GET['id']) && isset($_GET['token'])) {
        $id = $_GET['id'];
        $token = $_GET['token'];
    } else {
        echo "No se encontraron los parámetros 'id' y 'token' en la URL.";
        exit();
    }

    $nombre = '';
    $descripcion = '';
    $precio = 0.00;
    $descuento = 0;
    $precio_desc = 0;
    $token_tmp = '';

    if (empty($id) || empty($token)) {
        echo 'Error al cargar, falta el ID o el token.';
    } else {
        $token_tmp = hash_hmac('sha1', $id, KEY_TOKEN);
        if ($token == $token_tmp) {
            $sql = $con->prepare("SELECT COUNT(idproducto) FROM productos WHERE idproducto=? AND activo=1");
            $sql->execute([$id]);

            if ($sql->fetchColumn() > 0) {
                $sql = $con->prepare("SELECT nombreproducto, descripdetalle, precio, descuento FROM productos WHERE idproducto=? AND activo=1 LIMIT 1");
                $sql->execute([$id]);
                $resultado = $sql->fetch(PDO::FETCH_ASSOC);
                if ($resultado) {
                    $nombre = $resultado['nombreproducto'];
                    $descripcion = $resultado['descripdetalle'];
                    $precio = $resultado['precio'];
                    $descuento = $resultado['descuento'];
                    $precio_desc = $precio - (($precio * $descuento) / 100);
                    $dir_images = 'imagenes/Productos/' . $id . '/';
                    $rutaImg = $dir_images . 'principal.jpg';
                    if (!file_exists($rutaImg)) {
                        $rutaImg = 'imagenes/no-photo.jpg';
                    }
                    $imagenes = [];
                    if (file_exists($dir_images)) {
                        $dir = dir($dir_images);
                        while (($archivo = $dir->read()) !== false) {
                            if ($archivo != 'principal.jpg' && (strpos($archivo, '.jpg') !== false || strpos($archivo, '.jpeg') !== false)) {
                                $imagenes[] = $dir_images . $archivo;
                            }
                        }
                        $dir->close();
                    }
                }
            } else {
                echo 'No se encontró el producto.';
            }
        } else {
            echo 'Error al procesar la petición.';
        }
        $sql->closeCursor();
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ultra Gaming</title>
    <link rel="icon" href="imagenes/icono.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link href="css/estilos.css" rel="stylesheet">
</head>

<body>
<header data-bs-theme="dark">

<div class="navbar bg-primary navbar-dark navbar-expand-lg bg-dark " data-bs-theme="dark">
    <div class="container">
        <a href="index.php" class="navbar-brand d-flex align-items-center">
         <strong>Ultra Gaming store</strong>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class=" collapse navbar-collapse" id="navbarHeader">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                
                <li class="nav-item">
                    <a href="#" class="nav-link active"> Contacto </a>
                </li>
            </ul>

            <a href="checkout.php" class="btn btn-secondary position-relative me-5">
                Carrito
                <span id="num_cart" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                    <?php echo $num_cart; ?>
                    <span class="visually-hidden"></span>
                </span>
            </a>
            <?php if (isset($_SESSION['user_id'])) { ?>
                <a href="login.php" class="btn btn-success me-2"><?php echo $_SESSION['user_name']; ?></a>
                <a href="#" class="btn btn-danger" onclick="cerrarSesion()">Cerrar sesión</a>

            <?php } else { ?>
                <a href="login.php" class="btn btn-success">Ingresar</a>
            <?php }  ?>
        </div>
    </div>
</div>
</header>
    <main>
        <div class="container">
            <div class="row">
                <div class="col-md-6 order-md-1">

                    <div id="carouselExampleDark" class="carousel carousel-dark slide">
                        <div class="carouselImages">
                            <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                            <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
                            <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
                        </div>
                        <div class="carousel-inner">
                            <div class="carousel-item active" data-bs-interval="10000">

                                <img src="<?php echo $rutaImg; ?>" height="450" width="450" class="imagenes" style="display: block; margin: 0 auto;">
                                <div class="carousel-caption d-none d-md-block"></div>
                            </div>
                            <?php foreach ($imagenes as $img) { ?>
                                <div class="carousel-item" data-bs-interval="2000">
                                    <img src="<?php echo $img; ?>" height="450" width="450" style="display: block; margin: 0 auto;">
                                    <div class="carousel-caption d-none d-md-block"></div>
                                </div>

                            <?php } ?>

                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>
                <div class="col-md-6 order-md-2">
                    <h2><?php echo $nombre; ?> </h2>
                    <?php if ($descuento > 0) { ?>
                        <p><del><?php echo MONEDA . number_format($precio, 2, '.', ','); ?> </del></p>
                        <h2>
                            <?php echo MONEDA . number_format($precio_desc, 2, '.', ','); ?>
                            <small class="text-success"><?php echo $descuento; ?>% Descuento disponible</small>
                        </h2>
                    <?php } else { ?>
                        <h2><?php echo MONEDA . number_format($precio, 2, '.', ','); ?> </h2>
                    <?php } ?>
                    <p class="lead"> <?php echo $descripcion ?></p>
                    <div class="d-grid gap-3 col-10 mx-auto">
                        <div class="p-3 text-info-emphasis bg-info-subtle border border-info-subtle rounded-3" style="text-align: center;">
                            <h4>Comprar ahora !!!!</h4>
                        </div>
                        <button class="btn btn-outline-success" type="button" onclick="verificarSesion(<?php echo $id; ?>,'<?php echo $token_tmp ?>')">Agregar al carrito</button>
                    </div>
                </div>

            </div>
        </div>

    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script>
        function addProducto(id, token) {
            let url = 'clases/carrito.php'
            let formData = new FormData()
            formData.append('id', id)
            formData.append('token', token)

            fetch(url, {
                    method: 'POST',
                    body: formData,
                    mode: 'cors'
                }).then(response => response.json())
                .then(data => {
                    if (data.ok) {
                        let elemento = document.getElementById("num_cart")
                        elemento.innerHTML = data.numero
                    }
                })
        }

        function pagar(id, token) {
            let url = 'clases/carrito.php';
            let formData = new FormData();
            formData.append('id', id);
            formData.append('token', token);

            fetch(url, {
                    method: 'POST',
                    body: formData,
                    mode: 'cors'
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('La solicitud no fue exitosa');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.ok) {
                        let elemento = document.getElementById("num_cart");
                        elemento.innerHTML = data.numero;

                    } else {
                        console.error('Error en la respuesta: ', data.error);
                    }
                })
                .catch(error => {
                    console.error('Error en la solicitud: ', error);
                });
        }


        function verificarSesionPagar(idProducto, token) {
            <?php if (isset($_SESSION['user_id'])) { ?>
                pagar(idProducto, token);
            <?php } else { ?>
                console.log("Debe iniciar sesión para comprar");
                var respuesta = confirm("Debe iniciar sesión para agregar productos al carrito");
                if (respuesta) {
                    window.location.href = "http://localhost/Tienda%20Online%20Gamer/index.php";
                } else {
                    // El usuario eligió cancelar, puedes realizar alguna otra acción aquí si es necesario.
                }
            <?php } ?>
        }

        function verificarSesion(idProducto, token) {
            <?php if (isset($_SESSION['user_id'])) { ?>
                addProducto(idProducto, token);
            <?php } else { ?>
                console.log("Debe iniciar sesión para comprar");
                var respuesta = confirm("Debe iniciar sesión para agregar productos al carrito");
                if (respuesta) {
                    window.location.href = "http://localhost/Tienda%20Online%20Gamer/index.php";
                } else {
                    // El usuario eligió cancelar, puedes realizar alguna otra acción aquí si es necesario.
                }
            <?php } ?>
        }
        

        function cerrarSesion() {
            Swal.fire({
                title: '¿Estás seguro?',
                text: "¡Cerrar sesión terminará tu sesión actual!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Cerrar sesión',
                cancelButtonText: 'Cancelar',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch('cerrar_sesion.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.ok) {
                            Swal.fire({
                                title: 'Vuelva pronto',
                                text: 'Tu sesión ha sido cerrada con éxito.',
                                icon: 'success',
                                showConfirmButton: true,
                                confirmButtonText: 'OK'
                            }).then(() => {
                                window.location.href = 'index.php'; 
                            });
                        } else {
                            Swal.fire('Error', 'Hubo un problema al cerrar la sesión.', 'error');
                        }
                    })
                    .catch(error => {
                        Swal.fire('Error', 'No se pudo cerrar la sesión. Intente nuevamente.', 'error');
                    });
                }
            });
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</body>

</html>