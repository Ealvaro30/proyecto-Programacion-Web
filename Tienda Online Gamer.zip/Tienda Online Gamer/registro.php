<?php
require 'config/database.php';
require 'config/config.php';
require 'clases/clientesFunciones.php';
$db = new Database();
$con = $db->conectar();

$erros = [];

if (!empty($_POST)) {
    $pnombre = trim($_POST['pnombre']);
    $snombre = trim($_POST['snombre']);
    $papellido = trim($_POST['papellido']);
    $sapellido = trim($_POST['sapellido']);
    $email = trim($_POST['email']);
    $telefono = trim($_POST['telefono']);
    $cedula = trim($_POST['cedula']);
    $usuario = trim($_POST['usuario']);
    $password = trim($_POST['contrasena']);
    $repassword = trim($_POST['repassword']);

    if (!esEmail($email)) {
        $erros[] = "La dirección de correo electrónico no es válida";
    }
    if (!validaPassword($password, $repassword)) {
        $erros[] = "Las contraseñas no coinciden";
    }
    if (usuarioExiste($usuario, $con)) {
        $erros[] = "El nombre de usuario: $usuario ya existe";
    }
    if (emailExiste($email, $con)) {
        $erros[] = "El correo electrónico: $email ya existe";
    }
    if (esNulo([$pnombre, $snombre, $papellido, $sapellido, $email, $telefono, $cedula, $usuario, $password, $repassword])) {
        $erros[] = "Llenar todos los campos";
    }
    if (count($erros) == 0) {
        $id = registraCliente([$pnombre, $snombre, $papellido, $sapellido, $email, $telefono, $cedula], $con);

        if ($id > 0) {
            require 'clases/Mailer.php';
            $mailer = new Mailer();
            $token = generarToken();

            $pass_hash = password_hash($password, PASSWORD_DEFAULT);
            $idUsuario = registraUsuario([$usuario, $pass_hash, $token, $id], $con);
            if ($idUsuario > 0) {
                $url = URL_SITE.' activa_cliente.php?id=' . urlencode($idUsuario) . '&token=' . urlencode($token);
                $url2 = 'http://localhost/Tienda%20Online%20Gamer/index.php/activa_cliente.php?id=' . urlencode($idUsuario) . '&token=' . urlencode($token);
                

                $asunto = "Activar Cuenta - Tienda Online";
                $cuerpo = "Estimado $pnombre $papellido: <br> Para continuar con el proceso de registro es indispensable
                dar click en la siguiente liga
                <a href='$url2'> Activar cuenta</a>";

                if ($mailer->enviarEmail($email, $asunto, $cuerpo)) {
                    echo "Para terminar el proceso de registro, siga las instrucciones que se presentan a continuacion";
                    echo '<script>
                        var respuesta = confirm("Haga click en aceptar para activar la cuenta.");
                        if (respuesta) {
                                 window.open("' . $url . '", "_blank");
                        }
                        </script>';

                    
                } else {
                    $erros[] = "Dar click aqui para activar cuenta : <a href=".$url2."> Activar cuenta</a>";

                }
            } else {
                $erros[] = "Error al registrar usuario";
            }
        } else {
            $erros[] = "Error al registrar cliente";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ultra Gaming</title>
    <link rel="icon" href="imagenes/icono.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link href="css/estilos.css" rel="stylesheet">
</head>

<body>

    <header data-bs-theme="dark">

        <div class="navbar bg-primary navbar-dark navbar-expand-lg bg-dark " data-bs-theme="dark">
            <div class="container">
                <a href="index.php" class="navbar-brand d-flex align-items-center">
                    <strong>Ultra Gaming store</strong>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class=" collapse navbar-collapse" id="navbarHeader">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        
                        <li class="nav-item">
                            <a href="#" class="nav-link active"> Contacto </a>
                        </li>
                    </ul>

                    <a href="checkout.php" class="btn btn-secondary position-relative me-5">
                        Carrito
                        <span id="num_cart" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                            <?php echo $num_cart; ?>
                            <span class="visually-hidden"></span>
                        </span>
                    </a>
                </div>
            </div>
        </div>
    </header>
    <main>
        <div class="container">
            <h2>Datos del cliente </h2>
            <?php mostrarMensaje($erros); ?>
            <form class="row g-3" action="registro.php" method="POST" autocomplete="off">
                <div class="col-md-6">
                    <label for="pnombre"><span class="text-danger">*</span>Primer nombre</label>
                    <input type="text" name="pnombre" id="pnombre" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label for="papellido"><span class="text-danger">*</span>Segundo nombre</label>
                    <input type="text" name="papellido" id="papellido" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label for="snombre"><span class="text-danger">*</span>Primer apellido</label>
                    <input type="text" name="snombre" id="snombre" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label for="sapellido"><span class="text-danger"></span>Segundo apellido</label>
                    <input type="text" name="sapellido" id="sapellido" class="form-control">
                </div>
                <p id="nombre-apellido-error" class="text-danger"></p>

                <div class="col-md-6">
                    <label for="email"><span class="text-danger">*</span>Email</label>
                    <input type="email" name="email" id="email" class="form-control" required>
                    <span id="validaEmailError" class="text-danger"></span>
                </div>

                <div class="col-md-6">
                    <label for="telefono"><span class="text-danger">*</span>Telefono</label>
                    <input type="tel" name="telefono" id="telefono" class="form-control" required>
                    <p id="error-telefono" class="text-danger"></p>
                </div>
                <div class="col-md-6">
                    <label for="cedula"><span class="text-danger">*</span>Cedula</label>
                    <input type="text" name="cedula" id="cedula" class="form-control" required>
                    <p id="error-message" class="text-danger"></p>
                </div>
                <div class="col-md-6">
                    <label for="usuario"><span class="text-danger">*</span>Usuario</label>
                    <input type="text" name="usuario" id="usuario" class="form-control" requireda>
                    <span id="validaUsuario" class="text-danger"></span>
                </div>
                <div class="col-md-6">
                    <label for="contrasena"><span class="text-danger">*</span>Contraseña</label>
                    <input type="password" name="contrasena" id="contrasena" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label for="repassword"><span class="text-danger">*</span>Repetir contraseña</label>
                    <input type="password" name="repassword" id="repassword" class="form-control" required>
                    <p id="password-error" class="text-danger"></p>
                </div>
                <i><b>Nota:</b> Los campos asteriscos son obligatorios</i>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary">Registrar</button>
                </div>
            </form>

        </div>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script>
        var pnombreInput = document.getElementById('pnombre');
        var papellidoInput = document.getElementById('papellido');
        var snombreInput = document.getElementById('snombre');
        var sapellidoInput = document.getElementById('sapellido');
        var mensajeError = document.getElementById('nombre-apellido-error');

        pnombreInput.addEventListener('input', validarNombreApellido);
        papellidoInput.addEventListener('input', validarNombreApellido);
        snombreInput.addEventListener('input', validarNombreApellido);
        sapellidoInput.addEventListener('input', validarNombreApellido);

        function validarNombreApellido() {
            var pnombre = pnombreInput.value;
            var papellido = papellidoInput.value;
            var snombre = snombreInput.value;
            var sapellido = sapellidoInput.value;

            var formatoNombreApellido = /^[A-Za-z\s]+$/;

            if (!formatoNombreApellido.test(pnombre) || !formatoNombreApellido.test(papellido) || !formatoNombreApellido.test(snombre) || (sapellido !== "" && !formatoNombreApellido.test(sapellido))) {
                mensajeError.textContent = 'Los nombres y apellidos no son válidos';
            } else {
                mensajeError.textContent = '';
            }
        }
        let txtUsuario = document.getElementById('usuario');
        txtUsuario.addEventListener("blur", function() {
            existeUsuario(txtUsuario.value);

        }, false)
        let txtEmail = document.getElementById('email');
        txtEmail.addEventListener("blur", function() {
            existeEmail(txtEmail.value);

        }, false)
        document.getElementById('cedula').addEventListener('blur', function() {
            var cedulaInput = this.value;
            var formatoCedula = /^[0-9]{3}-[0-9]{6}-[0-9]{4}[A-Z]$/;
            if (!formatoCedula.test(cedulaInput)) {
                document.getElementById('error-message').textContent = 'El formato de cédula no es válido 000-000000-0000X';
                this.value = '';
            } else {
                document.getElementById('error-message').textContent = '';
            }
        });
        document.getElementById('email').addEventListener('blur', function() {
            var emailInput = this.value;
            var formatoEmail = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
            if (!formatoEmail.test(emailInput)) {
                document.getElementById('validaEmailError').innerHTML = 'El formato de correo no es válido';
                this.value = '';
            } else {
                document.getElementById('validaEmailError').textContent = ''
            }

        });
        document.getElementById('telefono').addEventListener('blur', function() {
            var telefonoInput = this.value;
            var formatoTelefono = /^[852][0-9]{7}$/;
            if (!formatoTelefono.test(telefonoInput)) {
                document.getElementById('error-telefono').textContent = 'El formato de teléfono no es válido 00000000 sin espacios';
                this.value = '';
            } else {
                document.getElementById('error-telefono').textContent = '';
            }
        });
        document.getElementById('contrasena').addEventListener('input', verificarCoincidenciaContrasena);
        document.getElementById('repassword').addEventListener('input', verificarCoincidenciaContrasena);

        function verificarCoincidenciaContrasena() {
            var contrasena = document.getElementById('contrasena').value;
            var repassword = document.getElementById('repassword').value;
            var mensajeError = document.getElementById('password-error');

            if (contrasena !== repassword) {
                mensajeError.textContent = 'Las contraseñas no coinciden';
            } else {
                mensajeError.textContent = '';
            }
        }

        function existeUsuario(usuario) {
            let url = "clases/clientesAjax.php"
            let formData = new FormData()
            formData.append("action", "existeUsuario")
            formData.append("usuario", usuario)

            fetch(url, {
                    method: 'POST',
                    body: formData
                }).then(response => response.json())
                .then(data => {
                    if (data.ok) {
                        document.getElementById('usuario').value = ''
                        document.getElementById('validaUsuario').innerHTML = 'Usuario no disponible eliga otro'

                    } else {
                        document.getElementById('validaUsuario').innerHTML = ''

                    }
                })
        }

        function existeEmail(email) {
            let url = "clases/clientesAjax.php"
            let formData = new FormData()
            formData.append("action", "existeEmail")
            formData.append("email", email)

            fetch(url, {
                    method: 'POST',
                    body: formData
                }).then(response => response.json())
                .then(data => {
                    if (data.ok) {
                        document.getElementById('email').value = ''
                        document.getElementById('validaEmailError').textContent = 'Correo electrónico ya registrado, no disponible'
                    }
                })
        }
    </script>
</body>

</html>