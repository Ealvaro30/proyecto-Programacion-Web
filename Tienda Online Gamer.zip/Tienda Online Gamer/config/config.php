<?php

define("CLIENT_ID", "AVHRD8ftRxow8_vl9p_Yjav-oVzocLZa2YjVeWcktMzyMiko7HIDAEaaLF5pBDdi2aw3RIPENMt4Xwls");
define("CURRENCY", "USD");
define("URL_SITE","http://localhost/Tienda%20Online%20Gamer");
define("KEY_TOKEN", "aaeg29100/*");
define("MAIL_HOST","tiendaonlinegamer710@gmail.com");
define("MAIL_USER","tiendaonlinegamer710@gmail.com");
define("MAIL_PASS","qwkxpydzxwskrzgp");
define("MAIL_PORT","587");
define("MONEDA", "$");

session_start();
$num_cart = 0;
if (isset($_SESSION['carrito']['productos'])) {
    $num_cart = count($_SESSION['carrito']['productos']);
}




?>
