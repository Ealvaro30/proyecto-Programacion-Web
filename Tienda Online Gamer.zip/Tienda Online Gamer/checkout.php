<?php

require 'config/database.php';
require 'config/config.php';
$db = new Database();
$con = $db->conectar();
$stock = 0;
$productos = isset($_SESSION['carrito']['productos']) ? $_SESSION['carrito']['productos'] : null;
$lista_carrito = array();
if ($productos != null) {
    foreach ($productos as $clave => $cantidad) {
        $sql = $con->prepare("select idproducto,nombreproducto,precio,descuento,$cantidad AS cantidad,stock from productos where idproducto=? and activo=1");
        $sql->execute([$clave]);
        $lista_carrito[] = $sql->fetch(pdo::FETCH_ASSOC);
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ultra Gaming</title>
    <link rel="icon" href="imagenes/icono.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link href="css/estilos.css" rel="stylesheet">
</head>

<body>
<header data-bs-theme="dark">

<div class="navbar bg-primary navbar-dark navbar-expand-lg bg-dark " data-bs-theme="dark">
    <div class="container">
        <a href="index.php" class="navbar-brand d-flex align-items-center">
         <strong>Ultra Gaming store</strong>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class=" collapse navbar-collapse" id="navbarHeader">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                
                <li class="nav-item">
                    <a href="#" class="nav-link active"> Contacto </a>
                </li>
            </ul>

            <a href="checkout.php" class="btn btn-secondary position-relative me-5">
                Carrito
                <span id="num_cart" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                    <?php echo $num_cart; ?>
                    <span class="visually-hidden"></span>
                </span>
            </a>
            <?php if (isset($_SESSION['user_id'])) { ?>
                <a href="login.php" class="btn btn-success me-2"><?php echo $_SESSION['user_name']; ?></a>
                <a href="#" class="btn btn-danger" onclick="cerrarSesion()">Cerrar sesión</a>

            <?php } else { ?>
                <a href="login.php" class="btn btn-success">Ingresar</a>
            <?php }  ?>
        </div>
    </div>
</div>
</header>
    <main>
        <div class="container">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Precio</th>
                            <th>Cantidad</th>
                            <th>Subtotal</th>
                            <th></th>

                        </tr>

                    </thead>
                    <tbody>

                        <?php
                        if ($lista_carrito == null) {
                            echo '<tr> <td colspan="5" class="text-center"><b>Carrito vacio siga navegando para selecionar sus productos</b></td></tr>';
                        } else {

                            $total = 0;


                            foreach ($lista_carrito as $producto) {
                                $_id = $producto['idproducto'];
                                $nombre = $producto['nombreproducto'];
                                $precio = $producto['precio'];
                                $descuento = $producto['descuento'];
                                $cantidad = $producto['cantidad'];
                                $stock = (int)$producto['stock'];
                                $precio_desc = $precio - (($precio * $descuento) / 100);
                                $subtotal = $cantidad * $precio_desc;
                                $total += $subtotal;

                        ?>

                                <tr>
                                    <td><?php echo $nombre; ?></td>
                                    <td><?php echo MONEDA . number_format($precio_desc, 2, '.', ','); ?></td>
                                    <td>
                                        <input type="number" value="<?php echo $cantidad; ?>" size="5" id="cantidad_<?php echo $_id; ?>" onkeydown="return true;" onmousedown="return true;" onwheel="return true;" onchange="actualizaCantidad(this.value > 1 ? this.value : 1, <?php echo $_id; ?>)">
                                    </td>




                                    <td>
                                        <div id="subtotal_<?php echo $_id; ?>" name="subtotal[]"><?php echo MONEDA . number_format($subtotal, 2, '.', ','); ?></div>
                                    </td>
                                    <td>
                                    <a href="#" id="eliminar" class="btn btn-warning btn-sm" data-id="<?php echo $_id; ?>" onclick="confirmarEliminacion()">Eliminar</a>
                                    </a>
                                    </td>


                                </tr>
                            <?php } ?>
                            <tr>
                                <td colspan="3"></td>
                                <td colspan="2">
                                    <p class="h3" id="total"><?php echo 'Grand Total: ' . MONEDA . number_format($total, 2, '.', ','); ?> </p>
                                </td>
                            </tr>
                    </tbody>
                <?php }
                ?>
                </table>
            </div>
            <?php
            if ($lista_carrito != null) { ?>
                <div class="row">
                    <div class="col-md-5 offset-md-7 d-grid gap-2">
                        <a href="pago.php" class="btn btn-primary btn-lg">Realizar pago </a>
                    </div>
                </div>
            <?php } ?>
        </div>
    </main>



    <script>
    function confirmarEliminacion() {
 
        let botOnElimina = document.getElementById('eliminar');
        let id = botOnElimina.getAttribute('data-id'); 
        
        
        Swal.fire({
            title: '¿Desea eliminar el producto de la lista?',
            text: "¡Esta acción no se puede deshacer!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Eliminar',
            cancelButtonText: 'Cancelar',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                eliminar(id);  
            }
        });
    }

    async function eliminar(id) {
        if (!id) {
            Swal.fire('Error', 'No se encontró el ID del producto.', 'error');
            return;
        }

        let url = 'clases/actualizar_carrito.php';
        let formData = new FormData();
        formData.append('action', 'eliminar');
        formData.append('id', id);

        try {
        let response = await fetch(url, {
            method: 'POST',
            body: formData,
            mode: 'cors'
        });

        let data = await response.json();

        if (data.ok) {
            Swal.fire({
                title: 'Eliminado',
                text: 'El producto ha sido eliminado con éxito.',
                icon: 'success',
                showConfirmButton: true, 
                confirmButtonText: 'OK'  
            }).then(() => {
                location.reload(); 
            });
        } else {
            Swal.fire('Error', 'Hubo un problema al eliminar el producto.', 'error');
        }
    } catch (error) {
        Swal.fire('Error', 'No se pudo realizar la eliminación. Intente nuevamente.', 'error');
    }
    }
</script>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script>
        let eliminaModal = document.getElementById('eliminaModal')
        eliminaModal.addEventListener('show.bs.modal', function(event) {
            let button = event.relatedTarget
            let id = button.getAttribute('data-bs-id')
            let buttoElimina = eliminaModal.querySelector('.modal-footer #btn-elimina')
            buttoElimina.value = id
        })



        function actualizaCantidad(cantidad, id) {
            let url = 'clases/actualizar_carrito.php'
            let formData = new FormData()
            formData.append('action', 'agregar')
            formData.append('id', id)
            formData.append('cantidad', cantidad)

            fetch(url, {
                    method: 'POST',
                    body: formData,
                    mode: 'cors'
                }).then(response => response.json())
                .then(data => {
                    if (data.ok) {
                        let divsubtotal = document.getElementById("subtotal_" + id)
                        divsubtotal.innerHTML = data.sub
                        let total = 0.00
                        let list = document.getElementsByName('subtotal[]')
                        for (let i = 0; i < list.length; i++) {
                            total += parseFloat(list[i].innerHTML.replace(/[$,]/g, ''))
                        }
                        total = new Intl.NumberFormat('en-US', {
                            minimumFractionDigits: 2

                        }).format(total)
                        document.getElementById('total').innerHTML = '<?php echo 'Grand Total: ' . MONEDA; ?>' + total
                        location.reload();
                    }
                })

        }
        function cerrarSesion() {
            Swal.fire({
                title: '¿Estás seguro?',
                text: "¡Cerrar sesión terminará tu sesión actual!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Cerrar sesión',
                cancelButtonText: 'Cancelar',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch('cerrar_sesion.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.ok) {
                            Swal.fire({
                                title: 'Vuelva pronto',
                                text: 'Tu sesión ha sido cerrada con éxito.',
                                icon: 'success',
                                showConfirmButton: true,
                                confirmButtonText: 'OK'
                            }).then(() => {
                                window.location.href = 'index.php'; 
                            });
                        } else {
                            Swal.fire('Error', 'Hubo un problema al cerrar la sesión.', 'error');
                        }
                    })
                    .catch(error => {
                        Swal.fire('Error', 'No se pudo cerrar la sesión. Intente nuevamente.', 'error');
                    });
                }
            });
        }
        
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</body>

</html>