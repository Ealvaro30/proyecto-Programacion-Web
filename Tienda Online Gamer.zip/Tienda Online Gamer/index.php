<?php
require 'config/database.php';
require 'config/config.php';

$db = new Database();
$con = $db->conectar();

$sql = $con->prepare("select idproducto,nombreproducto,precio, descuento,descripcion,stock from productos where activo=1");
$sql->execute();
$resultado = $sql->fetchAll(pdo::FETCH_ASSOC);
$_SESSION['intentos'] = 1;
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ultra Gaming</title>
    <link rel="icon" href="imagenes/icono.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet"> <!-- Agrega este enlace -->
    <link href="estilos.css" rel="stylesheet">
</head>



<header data-bs-theme="dark">

    <div class="navbar bg-primary navbar-dark navbar-expand-lg bg-dark " data-bs-theme="dark">
        <div class="container">
            <a href="index.php" class="navbar-brand d-flex align-items-center">
             <strong>Ultra Gaming store</strong>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class=" collapse navbar-collapse" id="navbarHeader">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                   
                    <li class="nav-item">
                        <a href="#" class="nav-link active"> Contacto </a>
                    </li>
                </ul>

                <a href="checkout.php" class="btn btn-secondary position-relative me-5">
                    Carrito
                    <span id="num_cart" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        <?php echo $num_cart; ?>
                        <span class="visually-hidden"></span>
                    </span>
                </a>
                <?php if (isset($_SESSION['user_id'])) { ?>
                    <a href="login.php" class="btn btn-success me-2"><?php echo $_SESSION['user_name']; ?></a>
                    <a href="#" class="btn btn-danger" onclick="cerrarSesion()">Cerrar sesión</a>

                <?php } else { ?>
                    <a href="login.php" class="btn btn-success">Ingresar</a>
                <?php }  ?>
            </div>
        </div>
    </div>
</header>

<body>
    <main>
        <div class="p-3 mb-2 bg-dark text-dark bg-opacity-90">
            <br>
            <div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active" data-bs-interval="2000">
                        <div class="carousel-caption">
                        </div>
                        <img src="imagenes/banner0.jpg" height="550" width="1380" style="display: block; margin: 0 auto; border-radius: 10px;">
                    </div>
                    <div class="carousel-item" data-bs-interval="2000">
                        <img src="imagenes/banner1.jpg" height="550" width="1380" style="display: block; margin: 0 auto; border-radius: 10px;">
                    </div>
                    <div class="carousel-item" data-bs-interval="2000">
                        <img src="imagenes/banner2.jpg" height="550" width="1380" style="display: block; margin: 0 auto; border-radius: 10px;">
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>


            <div class="container">
                <br>
                <br>
                <div>
                    <div class="card-body col shadow-lg p-6 mb-5 bg-body-tertiary rounded ">
                        <br>
                        <h1 class="text-primary" style="text-align: center;">Productos en Liquidación </h1><br>
                        <h3 style="text-align: center;"> Aprovecha hasta un <del class="text-success">25</del> % Menos</h3>
                    </div>
                </div>


                <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3 ">
                    <?php
                    $countLiquidacion = 0;
                    foreach ($resultado as $row) {
                        $id = $row['idproducto'];
                        $imagen = "imagenes/Productos/" . $id . "/principal.jpg";
                        $ruta = "imagenes/Productos/" . $id . "/principal2.jpg";
                        if (!file_exists($ruta)) {
                            $ruta = 'imagenes/no-photo.jpg';
                        }
                        $precio = $row['precio'];
                        $descuento = $row['descuento'];
                        $precio_desc = $precio - (($precio * $descuento) / 100);
                        $stock = $row['stock'];
                        if ($descuento > 0) {
                    ?>
                            <div>
                                <div class="card shadow-sm p-3 mb-2 bg-body-light rounded">
                                    <br>
                                    <?php if ($stock == 0) { ?>
                                        <h4 class="text-danger" style="text-align: center;"> Sin unidades disponibles</h4>
                                    <?php } ?>
                                    <h4 class="text-success" style="text-align: center;"> Descuento Disponible</h4>
                                    <img src="<?php echo $imagen; ?>" width="200" height="200" class="zoomable" style="display: block; margin: 0 auto;">
                                    <div class="card-body" style="text-align: center;">
                                        <h5 class="card-text"><?php echo $row['nombreproducto']; ?></h5>
                                        <p><del><?php echo MONEDA . number_format($precio, 2, '.', ','); ?> </del></p>
                                        <h4>
                                            <?php echo MONEDA . number_format($precio_desc, 2, '.', ','); ?>
                                            <small class="text-success"><?php echo $descuento; ?>% Menos aplicado</small>
                                        </h4>
                                        <div class="d-flex justify-content-between align-items-center" style="text-align: left;">
                                            <div class="card mb-3" style="max-width: 450px;">
                                                <div class="row g-0">
                                                    <div class="col-md-4">
                                                        <img src="<?php echo $ruta; ?>" width="100" height="100" class="img-fluid rounded-start" class="imagenes" style="display: block; margin: 0 auto;">
                                                    </div>
                                                    <div class="col-md-8">
                                                        <div class="card-body">
                                                            <h5 class="card-title">Detalles</h5>
                                                            <p class="card-text"><?php echo $row['descripcion']; ?></p>
                                                            <p class="card-text"><small class="text-body-primary">Descubre mas </small></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php if ($stock > 0) { ?>
                                            <div class="row">
                                                <div class="col">
                                                    <div class="btn-group">
                                                        <a href="detalles.php?id=<?php echo $row['idproducto']; ?>&token=<?php echo $token = hash_hmac('sha1', $row['idproducto'], KEY_TOKEN); ?>" class="btn btn-secondary">Más detalles</a>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <button class="btn btn-outline-success" type="button" onclick="verificarSesion(<?php echo $row['idproducto']; ?>,'<?php echo $token = hash_hmac('sha1', $row['idproducto'], KEY_TOKEN); ?>')">
                                                        Agregar
                                                    </button>
                                                </div>
                                            </div> <?php } ?>

                                    </div>
                                </div>
                            </div>
                    <?php
                            $countLiquidacion++;
                        }
                    }
                    ?>
                </div>

                <br>
                <div class="container my-4">
            <h2 class="text-info text-center mb-4">Descubre nuestras categorías</h2>
                <div class="row row-cols-2 row-cols-md-6 g-4">
                    <div class="col-2">
                        <div class="card shadow-sm">
                            <br>
                            <img src="imagenes/categoria1.png" class="card-img-top zoomable img-categoria" alt="Categoria 1">
                            <div class="card-body text-center">
                                
                                <h5 class="card-title">Teclados</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                        <br>
                            <img src="imagenes/categoria2.png" class="card-img-top zoomable img-categoria" alt="Categoria 2">
                            <div class="card-body text-center">
                                <h5 class="card-title">Ratones</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                        <br>
                            <img src="imagenes/categoria3.png" class="card-img-top zoomable img-categoria" alt="Categoria 3">
                            <div class="card-body text-center">
                                <h5 class="card-title">Monitores</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                        <br>
                            <img src="imagenes/categoria1.png" class="card-img-top zoomable img-categoria" alt="Categoria 1">
                            <div class="card-body text-center">
                                <h5 class="card-title">Teclados</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                        <br>
                            <img src="imagenes/categoria2.png" class="card-img-top zoomable img-categoria" alt="Categoria 2">
                            <div class="card-body text-center">
                                <h5 class="card-title">Ratones</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                        <br>
                            <img src="imagenes/categoria3.png" class="card-img-top zoomable img-categoria" alt="Categoria 3">
                            <div class="card-body text-center">
                                <h5 class="card-title">Monitores</h5>
                            </div>
                        </div>
                    </div>
                </div>
                

                    <br>
                <h2 class="text-info" style="text-align: center;">Productos Disponibles</h2><br>
                <div class="row row-cols-2 row-cols-sm-3 row-cols-md-3 g-5">
                    <?php
                    foreach ($resultado as $row) {
                        $id = $row['idproducto'];
                        $imagen = "imagenes/Productos/" . $id . "/principal.jpg";
                        $ruta = "imagenes/Productos/" . $id . "/principal2.jpg";
                        if (!file_exists($ruta)) {
                            $ruta = 'imagenes/no-photo.jpg';
                        }
                        $precio = $row['precio'];
                        $descuento = $row['descuento'];
                        $precio_desc = $precio - (($precio * $descuento) / 100);
                        $stock = $row['stock'];

                        if ($descuento == 0) {
                    ?>
                            <div class="col">
                                <div class="card shadow-sm ">
                                    <br>
                                    <?php if ($stock == 0) { ?>
                                        <h4 class="text-danger" style="text-align: center;"> Agotado</h4>
                                        <?php } ?>
                                    <h4 class="text-success" style="text-align: center;"> Prod. Nuevo</h4>
                                    <img src="<?php echo $imagen; ?>" width="150" height="150" style="display: block; margin: 0 auto;">
                                    <div class="card-body" style="text-align: center;">
                                        <h5 class="card-text"><?php echo $row['nombreproducto']; ?></h5>
                                        <p><?php echo MONEDA . number_format($precio, 2, '.', ','); ?></p>
                                        <?php if ($stock > 0) { ?>

                                            <div class="row">
                                                <div class="col">
                                                    <div class="btn-group">
                                                        <a href="detalles.php?id=<?php echo $row['idproducto']; ?>&token=<?php echo $token = hash_hmac('sha1', $row['idproducto'], KEY_TOKEN); ?>" class="btn btn-secondary">Más detalles</a>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="modal-footer">
                                                    <button class="btn btn-success" type="button" onclick="verificarSesion(<?php echo $row['idproducto']; ?>,'<?php echo $token = hash_hmac('sha1', $row['idproducto'], KEY_TOKEN); ?>')">
    Agregar
</button>
                                                    </div>

                                                </div>

                                            </div>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>

        </div>




    </main>
    <footer class="bg-dark text-white text-center py-4">
    <div class="container">
        <h4>Ultra Gaming Store</h4>
        <p>Dirección: Sucursal Los Robles De Pool 8, 50mtrs abajo.</p>
        <div class="d-flex justify-content-center">
            <a href="#" class="text-white mx-2"><i class="fab fa-facebook fa-2x"></i></a>
            <a href="#" class="text-white mx-2"><i class="fab fa-twitter fa-2x"></i></a>
            <a href="#" class="text-white mx-2"><i class="fab fa-instagram fa-2x"></i></a>
        </div>
    </div>
</footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script>
        function addProducto(id, token) {
            let url = 'clases/carrito.php'
            let formData = new FormData()
            formData.append('id', id)
            formData.append('token', token)

            fetch(url, {
                    method: 'POST',
                    body: formData,
                    mode: 'cors'
                }).then(response => response.json())
                .then(data => {
                    if (data.ok) {
                        let elemento = document.getElementById("num_cart")
                        elemento.innerHTML = data.numero
                    }
                })
        }

        function verificarSesion(idProducto, token) {
    <?php if (isset($_SESSION['user_id'])) { ?>
        addProducto(idProducto, token); 
    <?php } else { ?>
        Swal.fire({
            title: 'Debe iniciar sesión',
            text: "¡Inicia sesión para agregar productos al carrito!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Iniciar sesión',
            cancelButtonText: 'Cancelar',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "login.php";  
            }
        });
    <?php } ?>
}


                function cerrarSesion() {
            Swal.fire({
                title: '¿Estás seguro?',
                text: "¡Cerrar sesión terminará tu sesión actual!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Cerrar sesión',
                cancelButtonText: 'Cancelar',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch('cerrar_sesion.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.ok) {
                            Swal.fire({
                                title: 'Vuelva pronto',
                                text: 'Tu sesión ha sido cerrada con éxito.',
                                icon: 'success',
                                showConfirmButton: true,
                                confirmButtonText: 'OK'
                            }).then(() => {
                                window.location.href = 'index.php'; 
                            });
                        } else {
                            Swal.fire('Error', 'Hubo un problema al cerrar la sesión.', 'error');
                        }
                    })
                    .catch(error => {
                        Swal.fire('Error', 'No se pudo cerrar la sesión. Intente nuevamente.', 'error');
                    });
                }
            });
        }

    </script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</body>

</html>