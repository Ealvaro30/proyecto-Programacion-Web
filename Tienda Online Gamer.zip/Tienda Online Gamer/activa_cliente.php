<?php
require 'config/database.php';
require 'config/config.php';
require 'clases/clientesFunciones.php';
$db = new Database();
$con = $db->conectar();
$id = isset($_GET['id']) ? $_GET['id'] : '';
$token = isset($_GET['token']) ? $_GET['token'] : '';

if ($id == '' || $token == '') {
    header('Location http://localhost/Tienda%20Online%20Gamer/index.php');
    exit;
}

$mensaje = validaToken($id, $token, $con);

echo '<script>console.log("Resultado: ' . $mensaje . '");</script>';

echo '<script>
    var respuesta = confirm("Resultado: ' . $mensaje . '\n¿Desea redirigir a la página principal?");
    if (respuesta) {
        window.location.href = "http://localhost/Tienda%20Online%20Gamer/index.php";
    } else {
        // El usuario eligió cancelar, puedes realizar alguna otra acción aquí si es necesario.
    }
</script>';
?>
